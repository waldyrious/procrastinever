pref("extensions.procrastinever.boolpref", false);
pref("extensions.procrastinever.intpref", 0);
pref("extensions.procrastinever.stringpref", "A string");

// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.procrastinever@codebits.eu.description", "chrome://procrastinever/locale/procrastinever.properties");
